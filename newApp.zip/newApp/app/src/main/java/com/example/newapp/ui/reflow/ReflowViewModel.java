package com.example.newapp.ui.reflow;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

public class ReflowViewModel extends ViewModel {

    private final MutableLiveData<String> mText;
    private final MutableLiveData<List<Object>> itemsListLiveData;

    public ReflowViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("My Schedule");

        // Initialize the LiveData for itemsList
        itemsListLiveData = new MutableLiveData<>();
    }

    public LiveData<String> getText() {
        return mText;
    }

    // Add a method to get the LiveData for itemsList
    public LiveData<List<Object>> getItemsListLiveData() {
        return itemsListLiveData;
    }

    // Add a method to update the itemsList in the ViewModel
    public void setItemsList(List<Object> itemsList) {
        itemsListLiveData.setValue(itemsList);
    }
}