package com.example.newapp;
import java.io.Serializable;
public class Course implements Serializable {
    private String name;
    private String time;
    private String date;
    private String section;
    private String location;
    private String professor;

    // Constructor
    public Course(String name, String section, String professor, String date, String time, String location) {
        this.name = name;
        this.section = section;
        this.professor = professor;
        this.date = date;
        this.time = time;
        this.location = location;

    }

    // Getters and Setters
    public String getName() {
        return this.name;
    }
    public String getTime() {
        return this.time;
    }

    public String getDate() {
        return this.date;
    }

    public String getSection() {
        return this.section;
    }

    public String getLocation() {
        return this.location;
    }

    public String getProfessor() {
        return this.professor;
    }
    public void setName(String newName) {
    }
    public void setSection(String string) {
    }
    public void setProfessor(String string) {
    }
    public void setDate(String string) {
    }
    public void setTime(String string) {
    }
    public void setLocation(String string) {
    }
}
