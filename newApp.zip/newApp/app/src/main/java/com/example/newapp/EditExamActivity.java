package com.example.newapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class EditExamActivity extends AppCompatActivity {

    /*private Exam exam;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_exam);

        // Retrieve the Exam object passed from the ReflowFragment
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("exam")) {
            exam = (Exam) intent.getSerializableExtra("exam");

            // Populate the UI fields with exam data
            EditText descriptionEditText = findViewById(R.id.editTextExamDescription);
            EditText dateEditText = findViewById(R.id.editTextExamDate);
            EditText timeEditText = findViewById(R.id.editTextExamTime);
            EditText locationEditText = findViewById(R.id.editTextExamLocation);

            if (exam != null) {
                descriptionEditText.setText(exam.getDescription());
                dateEditText.setText(exam.getDate());
                timeEditText.setText(exam.getTime());
                locationEditText.setText(exam.getLocation());
            }
        }

        //handle save button click
        findViewById(R.id.buttonSaveExam).setOnClickListener(new View.OnClickListener() {
        //Button saveButton = findViewById(R.id.buttonSaveExam);
        //saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update exam object with new data

                if (exam !=null) {
                    EditText descriptionEditText = findViewById(R.id.editTextExamDescription);
                    EditText dateEditText = findViewById(R.id.editTextExamDate);
                    EditText timeEditText = findViewById(R.id.editTextExamTime);
                    EditText locationEditText = findViewById(R.id.editTextExamLocation);

                    exam.setDescription(descriptionEditText.getText().toString());
                    exam.setDate(dateEditText.getText().toString());
                    exam.setTime(timeEditText.getText().toString());
                    exam.setLocation(locationEditText.getText().toString());

                    // Pass the updated exam back to the calling activity
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("exam", exam);
                    setResult(RESULT_OK, resultIntent);

                    // Return to the previous screen
                    finish();
                }

                }
            });
        }*/

    private EditText descriptionEditText;
    private EditText dateEditText;
    private EditText timeEditText;
    private EditText locationEditText;
    private Exam exam;
    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_exam);

        descriptionEditText = findViewById(R.id.editTextExamDescription);
        dateEditText = findViewById(R.id.editTextExamDate);
        timeEditText = findViewById(R.id.editTextExamTime);
        locationEditText = findViewById(R.id.editTextExamLocation);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("exam")) {
            exam = (Exam) intent.getSerializableExtra("exam");
            position = intent.getIntExtra("position", -1);
            if (exam != null) {
                descriptionEditText.setText(exam.getDescription());
                dateEditText.setText(exam.getDate());
                timeEditText.setText(exam.getTime());
                locationEditText.setText(exam.getLocation());
            }
        }

        Button saveButton = findViewById(R.id.buttonSaveExam);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveExamChanges();
            }
        });
    }

    private void saveExamChanges() {
        String description = descriptionEditText.getText().toString();
        String date = dateEditText.getText().toString();
        String time = timeEditText.getText().toString();
        String location = locationEditText.getText().toString();

        if (description.isEmpty() || date.isEmpty() || time.isEmpty() || location.isEmpty()) {
            return;
        }

        Exam updatedExam = new Exam(description, date, time, location);

        Log.d("EditCourseActivity", "Updated Course: " + updatedExam.toString());

        Intent resultIntent = new Intent();
        resultIntent.putExtra("updated_exam", updatedExam);
        resultIntent.putExtra("position", position);
        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }
}
