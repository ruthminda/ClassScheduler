package com.example.newapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class EditAssignmentActivity extends AppCompatActivity {
    /*private Assignment assignment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_assignment);

        // Retrieve the Assignment object passed from the ReflowFragment
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("assignment")) {
            assignment = (Assignment) intent.getSerializableExtra("assignment");

            EditText titleEditText = findViewById(R.id.editTextAssignmentTitle);
            EditText courseEditText = findViewById(R.id.editTextCourseName);
            EditText dueDateEditText = findViewById(R.id.editTextDueDate);
            titleEditText.setText(assignment.getTitle());
            courseEditText.setText(assignment.getCourse());
            dueDateEditText.setText(assignment.getDueDate());
        }

        //handle save button click
        Button saveButton = findViewById(R.id.buttonSaveAssignment);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update assignment object with new data
                EditText titleEditText = findViewById(R.id.editTextAssignmentTitle);
                EditText courseEditText = findViewById(R.id.editTextCourseName);
                EditText dueDateEditText = findViewById(R.id.editTextDueDate);
                assignment.setTitle(titleEditText.getText().toString());
                assignment.setCourse(courseEditText.getText().toString());
                assignment.setDueDate(dueDateEditText.getText().toString());

                // Pass the updated assignment back to the calling activity
                Intent resultIntent = new Intent();
                resultIntent.putExtra("assignment", assignment);
                setResult(RESULT_OK, resultIntent);

                // Return to the previous screen
                finish();
                }
            });
    } */

    private EditText titleEditText;
    private EditText courseNameEditText;
    private EditText dueDateEditText;
    private Assignment assignment;
    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_assignment);

        titleEditText = findViewById(R.id.editTextAssignmentTitle);
        courseNameEditText = findViewById(R.id.editTextCourseName);
        dueDateEditText = findViewById(R.id.editTextDueDate);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("assignment")) {
            assignment = (Assignment) intent.getSerializableExtra("assignment");
            position = intent.getIntExtra("position", -1);
            if (assignment != null) {
                titleEditText.setText(assignment.getTitle());
                courseNameEditText.setText(assignment.getCourse());
                dueDateEditText.setText(assignment.getDueDate());
            }
        }

        Button saveButton = findViewById(R.id.buttonSaveAssignment);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveAssignmentChanges();
            }
        });
    }

    private void saveAssignmentChanges() {
        String title = titleEditText.getText().toString();
        String courseName = courseNameEditText.getText().toString();
        String dueDate = dueDateEditText.getText().toString();

        if (title.isEmpty() || courseName.isEmpty() || dueDate.isEmpty()) {
            return;
        }

        Assignment updatedAssignment = new Assignment(title, courseName, dueDate);

        Log.d("EditAssignmentActivity", "Updated Assignment: " + updatedAssignment.toString());

        Intent resultIntent = new Intent();
        resultIntent.putExtra("updated_assignment", updatedAssignment);
        resultIntent.putExtra("position", position);
        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }
}
