package com.example.newapp;
import java.io.Serializable;

public class Assignment implements Serializable {
    private String title;
    private String courseName;
    private String dueDate;

    // Constructor
    public Assignment(String title, String courseName, String dueDate) {
        this.title = title;
        this.courseName = courseName;
        this.dueDate = dueDate;
    }

    // Getters and Setters
    public String getTitle() {
        return this.title;
    }

    public String getCourse() {
        return this.courseName;
    }

    public String getDueDate() {
        return this.dueDate;
    }
    public void setTitle(String newTitle) {
    }
    public void setCourse(String string) {
    }
    public void setDueDate(String string) {
    }

    public String generateTaskContent() {
        return "Assignment: " + title + "\nCourse: " + courseName + "\nDue Date: " + dueDate;
    }

}
