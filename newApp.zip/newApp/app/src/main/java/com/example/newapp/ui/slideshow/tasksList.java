package com.example.newapp.ui.slideshow;

import java.util.ArrayList;

public class tasksList {
    private static ArrayList<Object> tasksList;

    public static ArrayList<Object> getTasksList() {
        if (tasksList == null) {
            synchronized (com.example.newapp.ui.reflow.itemsList.class) {
                if (tasksList == null) {
                    tasksList = new ArrayList<Object>();
                }
            }
        }
        return tasksList;
    }
}
