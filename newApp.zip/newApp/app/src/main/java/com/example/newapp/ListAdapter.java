package com.example.newapp;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_ASSIGNMENT = 0;
    private static final int TYPE_COURSE = 1;
    private static final int TYPE_EXAM = 2;

    private ArrayList<Object> items = com.example.newapp.ui.reflow.itemsList.getItemsList();
    //private final EventManager eventManager;

    private OnItemClickListener onItemClickListener;

    public interface OnItemClickListener {
        void onItemClick(Object item);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    public ListAdapter(ArrayList<Object> items) {
        this.items = items;
    }

//    public  ListAdapter(EventManager eventManager) {
//        this.eventManager = eventManager;
//        this.items = eventManager.getAllEvents();
//    }

    public int getItemViewType(int position) {
        Object item = items.get(position);
        if (item instanceof Assignment) {
            return TYPE_ASSIGNMENT;
        } else if (item instanceof Course) {
            return TYPE_COURSE;
        } else if (item instanceof Exam) {
            return TYPE_EXAM;
        }
        throw new IllegalArgumentException("Invalid item type at position: " + position);
    }

//    public void updateDataSet(List<Object> newList) {
//        items.clear();
//        items.addAll(newList);
//        notifyDataSetChanged();
//    }

    public <T> void updateDataSet(List<T> newList) {
        items.clear();
        items.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case TYPE_ASSIGNMENT:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.assignment_item, parent, false);
                return new AssignmentViewHolder(view);
            case TYPE_COURSE:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.course_item, parent, false);
                return new CourseViewHolder(view);
            case TYPE_EXAM:
                view = LayoutInflater.from(parent.getContext()).inflate(R.layout.exam_item, parent, false);
                return new ExamViewHolder(view);
            default:
                throw new IllegalArgumentException("Invalid view type");
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        int viewType = getItemViewType(position);
        switch (viewType) {
            case TYPE_ASSIGNMENT:
                Assignment assignment = (Assignment) items.get(position);
                AssignmentViewHolder assignmentHolder = (AssignmentViewHolder) holder;
                assignmentHolder.bind(assignment);
/*
                //click listener:
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Assignment clickedAssignment = (Assignment) items.get(position);
                        Intent intent = new Intent(view.getContext(), EditAssignmentActivity.class);
                        intent.putExtra("assignment", clickedAssignment);
                        view.getContext().startActivity(intent);
                    }
                });*/

                break;

            case TYPE_COURSE:
                Course course = (Course) items.get(position);
                CourseViewHolder courseHolder = (CourseViewHolder) holder;
                courseHolder.bind(course);
/*
                //click listener
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Course clickedCourse = (Course) items.get(position);
                        Intent intent = new Intent(view.getContext(), EditCourseActivity.class);
                        intent.putExtra("course", clickedCourse);
                        view.getContext().startActivity(intent);
                    }
                });*/

                break;
            case TYPE_EXAM:
                Exam exam = (Exam) items.get(position);
                ExamViewHolder examHolder = (ExamViewHolder) holder;
                examHolder.bind(exam);
/*
                //click listener
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // Retrieve the Exam object associated with the clicked item
                        Exam clickedExam = (Exam) items.get(position);
                        Intent intent = new Intent(view.getContext(), EditExamActivity.class);
                        intent.putExtra("exam", clickedExam);
                        view.getContext().startActivity(intent);
                    }
                }); */

                break;
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int position = holder.getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onItemClickListener != null) {
                    onItemClickListener.onItemClick(items.get(position));
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
    static class AssignmentViewHolder extends RecyclerView.ViewHolder {
        TextView titleView;
        TextView courseNameView;
        TextView dueDateView;

        public AssignmentViewHolder(View itemView) {
            super(itemView);
            titleView = itemView.findViewById(R.id.textViewAssignmentTitle);
            courseNameView = itemView.findViewById(R.id.textViewCourseName);
            dueDateView = itemView.findViewById(R.id.textViewDueDate);
        }

        public void bind(Assignment assignment) {
            titleView.setText(assignment.getTitle());
            courseNameView.setText("Course: " + assignment.getCourse());
            dueDateView.setText("Date: " + assignment.getDueDate());
        }
    }

    static class CourseViewHolder extends RecyclerView.ViewHolder {
        TextView courseNameView;
        TextView sectionView;
        TextView professorView;
        TextView dateView;
        TextView timeView;
        TextView locationView;
        public CourseViewHolder(View itemView) {
            super(itemView);
            courseNameView = itemView.findViewById(R.id.textViewCourseName);
            sectionView = itemView.findViewById(R.id.textViewCourseSection);
            professorView = itemView.findViewById(R.id.textViewCourseProfessor);
            dateView = itemView.findViewById(R.id.textViewCourseDate);
            timeView = itemView.findViewById(R.id.textViewCourseTime);
            locationView = itemView.findViewById(R.id.textViewCourseLocation);
        }

        public void bind(Course course) {
            courseNameView.setText(course.getName());
            sectionView.setText("Section: " + course.getSection());
            professorView.setText("Professor: " + course.getProfessor());
            dateView.setText("Date: " + course.getDate());
            timeView.setText("Time: " + course.getTime());
            locationView.setText("Location: " + course.getLocation());
        }
    }

    static class ExamViewHolder extends RecyclerView.ViewHolder {
        TextView examDescriptionView;
        TextView examDateView;
        TextView examTimeView;
        TextView examLocationView;
        public ExamViewHolder(View itemView) {
            super(itemView);
            examDescriptionView = itemView.findViewById(R.id.textViewExamDescription);
            examDateView = itemView.findViewById(R.id.textViewExamDate);
            examTimeView = itemView.findViewById(R.id.textViewExamTime);
            examLocationView = itemView.findViewById(R.id.textViewExamLocation);
        }

        public void bind(Exam exam) {
            examDescriptionView.setText(exam.getDescription());
            examDateView.setText("Date: " + exam.getDate());
            examTimeView.setText("Time: " + exam.getTime());
            examLocationView.setText("Location: " + exam.getLocation());
        }
    }
}


