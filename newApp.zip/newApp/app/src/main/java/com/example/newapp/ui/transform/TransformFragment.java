package com.example.newapp.ui.transform;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextClock;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.newapp.R;
import com.example.newapp.databinding.FragmentTransformBinding;
import com.example.newapp.databinding.ItemTransformBinding;
import java.util.Random;





/**
 * Fragment that demonstrates a responsive layout pattern where the format of the content
 * transforms depending on the size of the screen. Specifically this Fragment shows items in
 * the [RecyclerView] using LinearLayoutManager in a small screen
 * and shows items using GridLayoutManager in a large screen.
 */
public class TransformFragment extends Fragment {

    private FragmentTransformBinding binding;

    private String[] quotes = {
            "Believe you can and you're halfway there. -Theodore Roosevelt",
            "The only way to do great work is to love what you do. -Steve Jobs",
            "Your time is limited, don't waste it living someone else's life. -Steve Jobs",
            "The only way to achieve the impossible is to believe it is possible. - Charles Kingsleigh",
            "Success is not final, failure is not fatal: It is the courage to continue that counts. - Winston Churchill",
            "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
            "Your work is going to fill a large part of your life, and the only way to be truly satisfied is to do what you believe is great work. - Steve Jobs",
            "Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle. - Christian D. Larson",
            "The only limit to our realization of tomorrow will be our doubts of today. - Franklin D. Roosevelt",
            "Your attitude, not your aptitude, will determine your altitude. - Zig Ziglar",
            "The best way to predict the future is to create it. - Peter Drucker",
            "Don't watch the clock; do what it does. Keep going. - Sam Levenson",
            "The only person you are destined to become is the person you decide to be. - Ralph Waldo Emerson",
            "Believe you can and you're halfway there. - Theodore Roosevelt",
            "It always seems impossible until it's done. - Nelson Mandela",
            "The only place where success comes before work is in the dictionary. - Vidal Sassoon",
            "Your time is limited, so don't waste it living someone else's life. - Steve Jobs",
            "The future belongs to those who prepare for it today. - Malcolm X",
            "Success is stumbling from failure to failure with no loss of enthusiasm. - Winston Churchill",
            "The only limit to our realization of tomorrow will be our doubts of today. - Franklin D. Roosevelt",
            "It's not whether you get knocked down, it's whether you get up. - Vince Lombardi",
            "You are never too old to set another goal or to dream a new dream. - C.S. Lewis",
            "Do not wait to strike till the iron is hot, but make it hot by striking. - William Butler Yeats",

    };

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_transform, container, false);

        RelativeLayout relativeLayout = root.findViewById(R.id.recyclerview_transform);

        CalendarView calendarView = new CalendarView(requireContext());

        RelativeLayout.LayoutParams calendarLayoutParams = new RelativeLayout.LayoutParams(
                1000, 1600);
        calendarLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_START);
        calendarView.setLayoutParams(calendarLayoutParams);

        relativeLayout.addView(calendarView);

        TextView quoteTextView = new TextView(requireContext());
        quoteTextView.setId(View.generateViewId());

        quoteTextView.setTextAppearance(requireContext(), android.R.style.TextAppearance_Medium);
        quoteTextView.setTextColor(Color.parseColor("#7FFFD4"));
        quoteTextView.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        quoteTextView.setTypeface(null, android.graphics.Typeface.BOLD);

        RelativeLayout.LayoutParams quoteLayoutParams = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        quoteLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
        quoteLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_START);
        quoteLayoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
        quoteLayoutParams.setMargins(16, 0, 0, 16);

        displayRandomQuote(quoteTextView);

        relativeLayout.addView(quoteTextView, quoteLayoutParams);

        return root;
    }

    private void displayRandomQuote(TextView quoteTextView) {

        String randomQuote = getRandomQuote();

        quoteTextView.setText(randomQuote);
    }

    private String getRandomQuote() {

        Random random = new Random();
        int randomIndex = random.nextInt(quotes.length);
        return quotes[randomIndex];
    }
}
