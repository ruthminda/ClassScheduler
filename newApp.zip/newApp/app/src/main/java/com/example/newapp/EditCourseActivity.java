package com.example.newapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class EditCourseActivity extends AppCompatActivity {
    /*private Course course;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_course);

        // Retrieve the Course object passed from the ReflowFragment
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("course")) {
            course = (Course) intent.getSerializableExtra("course");

            // Populate the UI fields with course data
            EditText nameEditText = findViewById(R.id.editTextCourseName);
            EditText sectionEditText = findViewById(R.id.editTextCourseSection);
            EditText professorEditText = findViewById(R.id.editTextCourseProfessor);
            EditText dateEditText = findViewById(R.id.editTextCourseDate);
            EditText timeEditText = findViewById(R.id.editTextCourseTime);
            EditText locationEditText = findViewById(R.id.editTextCourseLocation);
            nameEditText.setText(course.getName());
            sectionEditText.setText(course.getSection());
            professorEditText.setText(course.getProfessor());
            dateEditText.setText(course.getDate());
            timeEditText.setText(course.getTime());
            locationEditText.setText(course.getLocation());
        }

        // Handle save button click
        Button saveButton = findViewById(R.id.buttonSaveCourse);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Update course object with new data
                EditText nameEditText = findViewById(R.id.editTextCourseName);
                EditText sectionEditText = findViewById(R.id.editTextCourseSection);
                EditText professorEditText = findViewById(R.id.editTextCourseProfessor);
                EditText dateEditText = findViewById(R.id.editTextCourseDate);
                EditText timeEditText = findViewById(R.id.editTextCourseTime);
                EditText locationEditText = findViewById(R.id.editTextCourseLocation);
                course.setName(nameEditText.getText().toString());
                course.setSection(sectionEditText.getText().toString());
                course.setProfessor(professorEditText.getText().toString());
                course.setDate(dateEditText.getText().toString());
                course.setTime(timeEditText.getText().toString());
                course.setLocation(locationEditText.getText().toString());

                // Pass the updated course back to the calling activity
                Intent resultIntent = new Intent();
                resultIntent.putExtra("course", course);
                setResult(RESULT_OK, resultIntent);

                // Return to the previous screen
                finish();
                }
            });
        }*/

    private EditText nameEditText;
    private EditText sectionEditText;
    private EditText professorEditText;
    private EditText dateEditText;
    private EditText timeEditText;
    private EditText locationEditText;
    private Course course;
    private int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_course);

        nameEditText = findViewById(R.id.editTextCourseName);
        sectionEditText = findViewById(R.id.editTextCourseSection);
        professorEditText = findViewById(R.id.editTextCourseProfessor);
        dateEditText = findViewById(R.id.editTextCourseDate);
        timeEditText = findViewById(R.id.editTextCourseTime);
        locationEditText = findViewById(R.id.editTextCourseLocation);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("course")) {
            course = (Course) intent.getSerializableExtra("course");
            position = intent.getIntExtra("position", -1);
            if (course != null) {
                nameEditText.setText(course.getName());
                sectionEditText.setText(course.getSection());
                professorEditText.setText(course.getProfessor());
                dateEditText.setText(course.getDate());
                timeEditText.setText(course.getTime());
                locationEditText.setText(course.getLocation());
            }
        }

        Button saveButton = findViewById(R.id.buttonSaveCourse);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCourseChanges();
            }
        });
    }

    private void saveCourseChanges() {
        String name = nameEditText.getText().toString();
        String section = sectionEditText.getText().toString();
        String professor = professorEditText.getText().toString();
        String date = dateEditText.getText().toString();
        String time = timeEditText.getText().toString();
        String location = locationEditText.getText().toString();

        if (name.isEmpty() || section.isEmpty() || professor.isEmpty() || date.isEmpty() || time.isEmpty() || location.isEmpty()) {
            return;
        }

        Course updatedCourse = new Course(name, section, professor, date, time, location);

        Log.d("EditCourseActivity", "Updated Course: " + updatedCourse.toString());

        Intent resultIntent = new Intent();
        resultIntent.putExtra("updated_course", updatedCourse);
        resultIntent.putExtra("position", position);
        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }
}
