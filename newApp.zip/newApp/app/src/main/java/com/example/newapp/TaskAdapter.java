package com.example.newapp;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {
    private ArrayList<Object> tasks = com.example.newapp.ui.slideshow.tasksList.getTasksList();

    public TaskAdapter(ArrayList<Object> tasks) {
        this.tasks = tasks;
    }

    public <T> void updateDataSet(List<T> newList) {
        tasks.clear();
        tasks.addAll(newList);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.to_do_item, parent, false);
        return new TaskViewHolder(view, this);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = (Task) tasks.get(position);
        holder.bind(task);
    }

    @Override
    public int getItemCount() {
        return tasks.size();
    }

    public void removeTask(int position) {
        tasks.remove(position);
        notifyItemRemoved(position);
    }

    public interface OnTaskItemClickListener {
        void onTaskItemClick(Task task);
    }

    private static OnTaskItemClickListener taskItemClickListener;

    public void setOnTaskItemClickListener(OnTaskItemClickListener listener) {
        this.taskItemClickListener = listener;
    }

    public static class TaskViewHolder extends RecyclerView.ViewHolder {
        CheckBox checkBox;
        TextView textViewTask;
        TaskAdapter adapter;
        private Task task;

        public TaskViewHolder(@NonNull View itemView, TaskAdapter adapter) {
            super(itemView);
            this.adapter = adapter;
            checkBox = itemView.findViewById(R.id.checkbox);
            textViewTask = itemView.findViewById(R.id.textViewTask);

            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    int adapterPosition = getAdapterPosition();
                    if (adapterPosition != RecyclerView.NO_POSITION) {
                        Task task = (Task) adapter.tasks.get(adapterPosition);
                        task.setCompleted(isChecked);
                        if (isChecked) {
                            adapter.removeTask(adapterPosition);
                        }
                    }
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (taskItemClickListener != null) {
                        taskItemClickListener.onTaskItemClick(task);
                    }
                }
            });
        }

        public void bind(Task task) {
            this.task = task;
            checkBox.setChecked(task.isCompleted());
            textViewTask.setText(task.getTaskName());

        }

    }
}
