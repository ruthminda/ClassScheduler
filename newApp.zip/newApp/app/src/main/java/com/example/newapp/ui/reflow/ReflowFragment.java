package com.example.newapp.ui.reflow;
        import com.example.newapp.Course;
        import com.example.newapp.EditAssignmentActivity;
        import com.example.newapp.EditCourseActivity;
        import com.example.newapp.EditExamActivity;
        import com.example.newapp.Exam;
        import com.example.newapp.R;

        import android.app.Activity;
        import android.app.AlertDialog;
        import android.content.DialogInterface;
        import android.content.Intent;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

        import androidx.annotation.NonNull;
        import androidx.annotation.Nullable;
        import androidx.fragment.app.Fragment;
        import androidx.lifecycle.ViewModelProvider;
        import androidx.recyclerview.widget.LinearLayoutManager;
        import androidx.recyclerview.widget.RecyclerView;

        import com.example.newapp.Assignment;
        import com.example.newapp.databinding.FragmentReflowBinding;
        import com.example.newapp.ListAdapter;

        import java.sql.Array;
        import java.util.ArrayList;
        import java.util.Collections;
        import java.util.Comparator;
        import java.util.List;

public class ReflowFragment extends Fragment implements ListAdapter.OnItemClickListener {

    private FragmentReflowBinding binding;
    private ArrayList<Object> itemsList = com.example.newapp.ui.reflow.itemsList.getItemsList();
    private ListAdapter listAdapter = new ListAdapter(itemsList);
    private static final int EDIT_ASSIGNMENT_REQUEST_CODE = 1;
    private static final int EDIT_COURSE_REQUEST_CODE = 2;
    private static final int EDIT_EXAM_REQUEST_CODE = 3;

    private ArrayList<Object> oglist = new ArrayList<>();
    private ArrayList<Object> original = new ArrayList<>();

    private ReflowViewModel reflowViewModel;


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        reflowViewModel = new ViewModelProvider(requireActivity()).get(ReflowViewModel.class); //justAdded
        listAdapter.setOnItemClickListener(this);
        setupFilterButton();
    }

    @Override
    public void onItemClick(Object item) {

        if (item instanceof Course) {
            //open editing screen for course
            Course course = (Course) item;
            openCourseEditScreen(course, itemsList.indexOf(course));
        } else if (item instanceof Assignment) {
            //open editing screen for assignment
            Assignment assignment = (Assignment) item;
            openAssignmentEditScreen(assignment, itemsList.indexOf(assignment));
        } else if (item instanceof Exam) {
            //open editing screen for exam
            Exam exam = (Exam) item;
            openExamEditScreen(exam, itemsList.indexOf(exam));
        }
    }

    private void openCourseEditScreen(Course course, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Modify Course Details");
        builder.setMessage("Would you like to edit or delete this course?");
        builder.setPositiveButton("Edit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(requireContext(), EditCourseActivity.class);
                intent.putExtra("course", course);
                intent.putExtra("position", position);
                startActivityForResult(intent, EDIT_COURSE_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteCourse(course, position);
            }
        });
        builder.setNeutralButton("Cancel", null);
        builder.show();

    }
    private void deleteCourse(Course course, int position) {
        AlertDialog.Builder deleteConfirmationBuilder = new AlertDialog.Builder(requireContext());
        deleteConfirmationBuilder.setTitle("Delete Confirmation");
        deleteConfirmationBuilder.setMessage("Are you sure you want to delete this course?");
        deleteConfirmationBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int origPos = itemsList.indexOf(course);
                itemsList.remove(origPos);
                oglist.remove(origPos);
                original.remove(origPos);

                listAdapter.notifyItemRemoved(origPos);

                Toast.makeText(requireContext(), "Course deleted", Toast.LENGTH_SHORT).show();
            }
        });
        deleteConfirmationBuilder.setNegativeButton("No", null);
        deleteConfirmationBuilder.show();
    }

    private void openAssignmentEditScreen(Assignment assignment,  int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Modify Assignment Details");
        builder.setMessage("Would you like to edit or delete this assignment?");
        builder.setPositiveButton("Edit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(requireContext(), EditAssignmentActivity.class);
                intent.putExtra("assignment", assignment);
                intent.putExtra("position", position);
                startActivityForResult(intent, EDIT_ASSIGNMENT_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteAssignment(assignment, position);
            }
        });
        builder.setNeutralButton("Cancel", null);
        builder.show();
    }

    private void deleteAssignment(Assignment assignment, int position) {
        AlertDialog.Builder deleteConfirmationBuilder = new AlertDialog.Builder(requireContext());
        deleteConfirmationBuilder.setTitle("Delete Confirmation");
        deleteConfirmationBuilder.setMessage("Are you sure you want to delete this assignment?");
        deleteConfirmationBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int origPos = itemsList.indexOf(assignment);
                itemsList.remove(origPos);
                oglist.remove(origPos);
                original.remove(origPos);

                listAdapter.notifyItemRemoved(origPos);

                Toast.makeText(requireContext(), "Assignment deleted", Toast.LENGTH_SHORT).show();
            }
        });
        deleteConfirmationBuilder.setNegativeButton("No", null);
        deleteConfirmationBuilder.show();
    }

    private void openExamEditScreen(Exam exam, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Modify Exam Details");
        builder.setMessage("Would you like to edit or delete this exam?");
        builder.setPositiveButton("Edit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(requireContext(), EditExamActivity.class);
                intent.putExtra("exam", exam);
                intent.putExtra("position", position);
                startActivityForResult(intent, EDIT_EXAM_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteExam(exam, position);
            }
        });
        builder.setNeutralButton("Cancel", null);
        builder.show();
    }

    private void deleteExam(Exam exam, int position) {
        AlertDialog.Builder deleteConfirmationBuilder = new AlertDialog.Builder(requireContext());
        deleteConfirmationBuilder.setTitle("Delete Confirmation");
        deleteConfirmationBuilder.setMessage("Are you sure you want to delete this exam?");
        deleteConfirmationBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int origPos = itemsList.indexOf(exam);
                itemsList.remove(origPos);
                oglist.remove(origPos);
                original.remove(origPos);

                listAdapter.notifyItemRemoved(origPos);

                Toast.makeText(requireContext(), "Exam deleted", Toast.LENGTH_SHORT).show();
            }
        });
        deleteConfirmationBuilder.setNegativeButton("No", null);
        deleteConfirmationBuilder.show();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK && data != null) {
            int position = data.getIntExtra("position", -1);
            if (position != -1) {
                switch (requestCode) {
                    case EDIT_ASSIGNMENT_REQUEST_CODE:
                        if (data.hasExtra("updated_assignment")) {
                            Assignment updatedAssignment = (Assignment) data.getSerializableExtra("updated_assignment");
                            updateItem(position, updatedAssignment);
                        }
                        break;
                    case EDIT_COURSE_REQUEST_CODE:
                        if (data.hasExtra("updated_course")) {
                            Course updatedCourse = (Course) data.getSerializableExtra("updated_course");
                            updateItem(position, updatedCourse);
                        }
                        break;
                    case EDIT_EXAM_REQUEST_CODE:
                        if (data.hasExtra("updated_exam")) {
                            Exam updatedExam = (Exam) data.getSerializableExtra("updated_exam");
                            updateItem(position, updatedExam);
                        }
                        break;
                }
            }
        }
    }

    private void updateItem(int position, Object updatedItem) {
        itemsList.set(position, updatedItem);
        int ogListPosition = oglist.indexOf(itemsList.get(position));
        if (ogListPosition != -1) {
            oglist.remove(ogListPosition);
            original.remove(ogListPosition);
        }
        oglist.add(updatedItem);
        original.add(updatedItem);

        listAdapter.notifyItemChanged(position);
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        reflowViewModel = new ViewModelProvider(requireActivity()).get(ReflowViewModel.class);

        binding = FragmentReflowBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.scheduleHeader;
        reflowViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);

        reflowViewModel.getItemsListLiveData().observe(getViewLifecycleOwner(), newList -> {
            itemsList.clear();
            itemsList.addAll(newList);
            listAdapter.notifyDataSetChanged();
        });

        RecyclerView recyclerView = binding.listView;
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(listAdapter);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAddItemDialog();
            }
        });

        return root;
    }

    private void showAddItemDialog() {
        final CharSequence[] items = {"Course", "Assignment", "Exam"};

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Add a...")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Handle the selection here
                        switch (which) {
                            case 0:
                                courseData();
                                break;
                            case 1:
                                assignmentData();
                                break;
                            case 2:
                                examData();
                                break;
                        }
                    }
                });
        builder.show();
    }

    private void assignmentData() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.assignment_item_make, null);

        EditText titleInput = view.findViewById(R.id.editTextAssignmentTitle);
        EditText courseNameInput = view.findViewById(R.id.editTextCourseName);
        EditText dueDateInput = view.findViewById(R.id.editTextDueDate);

        builder.setView(view)
                .setTitle("Add Assignment Details")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        String title = titleInput.getText().toString();
                        String courseName = courseNameInput.getText().toString();
                        String dueDate = dueDateInput.getText().toString();

                        Assignment assignment = new Assignment(title, courseName, dueDate);
                        addNewItem(assignment);
                        //addNewItemToEventManager(assignment);
                    }

                })
                .setNegativeButton("Cancel", (dialog, id) -> dialog.cancel());

        AlertDialog dialog = builder.create();
        dialog.show();
    }


    private void examData() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.exam_item_make, null);

        EditText descInput = view.findViewById(R.id.editTextExamDescription);
        EditText dateInput = view.findViewById(R.id.editTextExamDate);
        EditText timeInput = view.findViewById(R.id.editTextExamTime);
        EditText locationInput = view.findViewById(R.id.editTextExamLocation);

        builder.setView(view)
                .setTitle("Add Exam Details")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        String description = descInput.getText().toString();
                        String date = dateInput.getText().toString();
                        String time = timeInput.getText().toString();
                        String location = locationInput.getText().toString();

                        Exam exam = new Exam(description, date, time, location);
                        addNewItem(exam);
                        //addNewItemToEventManager(exam);
                    }
                })
                .setNegativeButton("Cancel", (dialog, id) -> dialog.cancel());

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void courseData() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.course_item_make, null);

        EditText nameInput = view.findViewById(R.id.editTextCourseName);
        EditText secInput = view.findViewById(R.id.editTextCourseSection);
        EditText profInput = view.findViewById(R.id.editTextCourseProfessor);
        EditText dateInput = view.findViewById(R.id.editTextCourseDate);
        EditText locationInput = view.findViewById(R.id.editTextCourseLocation);
        EditText timeInput = view.findViewById(R.id.editTextCourseTime);

        builder.setView(view)
                .setTitle("Add Course Details")
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        String name = nameInput.getText().toString();
                        String section = secInput.getText().toString();
                        String prof = profInput.getText().toString();
                        String date = dateInput.getText().toString();
                        String location = locationInput.getText().toString();
                        String time = timeInput.getText().toString();

                        Course course = new Course(name, section, prof, date, time, location);
                        addNewItem(course);
                        //addNewItemToEventManager(course);
                    }
                })
                .setNegativeButton("Cancel", (dialog, id) -> dialog.cancel());

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void addNewItem(Object newItem) {
        Log.d("AddNewItem", "Adding new item: " + newItem.toString());
        itemsList.add(newItem);
        oglist.add(newItem);
        original.add(newItem);
        Log.d("AddNewItem", "Item added. List size: " + itemsList.size());
        listAdapter.notifyItemInserted(itemsList.size() - 1);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void setupFilterButton() {
        binding.btnFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showFilterOptionsDialog();
            }
        });
    }

    private void showFilterOptionsDialog() {
        final CharSequence[] items = {"View All", "Assignment", "Exam", "Course"};

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Filter Options")
                .setItems(items, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Handle the selection here
                        handleFilterSelection(items[which].toString());
                    }
                });
        builder.show();
    }

    private void handleFilterSelection(String filterOption) {
//        ArrayList<Object> oglist = itemsList;
        switch (filterOption) {
            case "Assignment":
                showAssignmentSortingOptions();
                break;
            case "Exam":
                filterListByType(Exam.class);
                break;
            case "Course":
                filterListByType(Course.class);
                break;
            case "View All":
                itemsList.clear();
                itemsList.addAll(oglist);
                listAdapter.updateDataSet(oglist);
                break;
        }
    }

    private void showAssignmentSortingOptions() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Sort Assignments")
                .setItems(new CharSequence[]{"By Due Date", "By Course Name"}, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        switch (i) {
                            case 0:
                                sortByDueDate();
                                break;
                            case 1:
                                sortByCourseName();
                                break;
                        }
                    }
                });
        builder.show();
    }

    private void sortByDueDate() {
        List<Assignment> assignments = filterListByType(Assignment.class);
        Collections.sort(assignments, new Comparator<Assignment>() {
            @Override
            public int compare(Assignment assignment1, Assignment assignment2) {
                return assignment1.getDueDate().compareTo(assignment2.getDueDate());
            }
        });
        listAdapter.updateDataSet(assignments);
    }

    private void sortByCourseName() {
        List<Assignment> assignments = filterListByType(Assignment.class);
        Collections.sort(assignments, new Comparator<Assignment>() {
            @Override
            public int compare(Assignment assignment1, Assignment assignment2) {
                return assignment1.getCourse().compareTo(assignment2.getCourse());
            }
        });
        listAdapter.updateDataSet(assignments);
    }

    private <T> List<T> filterListByType(Class<T> type) {
        itemsList = original;
        System.out.println(itemsList);
        List<T> filteredList = new ArrayList<>();
        for (Object item : itemsList) {
            if (type.isInstance(item)) {
                filteredList.add(type.cast(item));
            }
        }
        System.out.println(itemsList);
        listAdapter.updateDataSet(filteredList);
        System.out.println(filteredList);
        System.out.println(itemsList);
        return filteredList;
    }

}