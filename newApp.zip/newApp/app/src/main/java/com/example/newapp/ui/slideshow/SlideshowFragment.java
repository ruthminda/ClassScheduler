package com.example.newapp.ui.slideshow;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.newapp.Assignment;
import com.example.newapp.Exam;
import com.example.newapp.R;
import com.example.newapp.Task;
import com.example.newapp.TaskAdapter;
import com.example.newapp.databinding.FragmentSlideshowBinding;
import com.example.newapp.ui.reflow.ReflowViewModel;
import com.example.newapp.ui.reflow.itemsList;

import java.util.ArrayList;
import java.util.List;

public class SlideshowFragment extends Fragment {

    private FragmentSlideshowBinding binding;
    private ArrayList<Object> taskList;
    private TaskAdapter taskAdapter = new TaskAdapter(taskList);


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentSlideshowBinding.inflate(inflater, container, false);
        View root = binding.getRoot();



        taskList = tasksList.getTasksList();
        taskAdapter = new TaskAdapter(taskList);
        taskAdapter.setOnTaskItemClickListener(this::onTaskItemClick);

        RecyclerView recyclerView = root.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(taskAdapter);

        ArrayList<Object> items = itemsList.getItemsList();
        for (Object item : items) {
            if (item instanceof Assignment) {
                String taskContent = ((Assignment) item).generateTaskContent();
                addItemTask(taskContent);
            } else if (item instanceof Exam) {
                String taskContent = ((Exam) item).generateTaskContent();
                addItemTask(taskContent);
            }
        }

        final EditText taskEditText = root.findViewById(R.id.taskEditText);

        Button addTaskButton = root.findViewById(R.id.addTaskButton);
        addTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTask(taskEditText);
            }
        });


        return root;
    }

    public void onTaskItemClick(final Task task) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Edit Task");

        final EditText editText = new EditText(requireContext());
        editText.setText(task.getTaskName());
        builder.setView(editText);

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String updatedTaskName = editText.getText().toString().trim();
                if (!updatedTaskName.isEmpty()) {
                    task.setTaskName(updatedTaskName);
                    taskAdapter.notifyDataSetChanged();
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    private void addTask(EditText taskEditText) {
        String taskName = taskEditText.getText().toString().trim();

        if (!taskName.isEmpty()) {
            Task newTask = new Task(taskName, false);
            taskList.add(newTask);
            taskAdapter.notifyDataSetChanged();
            taskEditText.setText(""); // Clear the EditText after adding a task
        }
    }

    public void addItemTask(String taskName) {
        if (!taskName.isEmpty()) {
            Task newTask = new Task(taskName, false);
            taskList.add(newTask);
            taskAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onDestroyView() {
        Log.d("SlideshowFragment", "onDestroyView");
        super.onDestroyView();
        binding = null;
    }
}
