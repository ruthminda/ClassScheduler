package com.example.newapp;
import java.io.Serializable;
public class Exam implements Serializable {
    private String date;

    private String description;
    private String time;
    private String location;

    // Constructor
    public Exam(String description, String date, String time, String location) {
        this.description = description;
        this.date = date;
        this.time = time;
        this.location = location;
    }

    // Getters and Setters

    public String getDescription() {
        return this.description;
    }
    public String getDate() {
        return this.date;
    }

    public String getTime() {

        return this.time;
    }
    public String getLocation() {
        return this.location;
    }

    public void setDescription(String newDescription) {
    }
    public void setDate(String string) {
    }
    public void setTime(String string) {
    }
    public void setLocation(String string) {
    }

    public String generateTaskContent() {
        return "Exam: " + description + "\nDate: " + date + "\nTime: " + time + "\nLocation: " + location;
    }
}
