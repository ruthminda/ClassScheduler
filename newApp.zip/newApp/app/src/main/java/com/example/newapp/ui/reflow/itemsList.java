package com.example.newapp.ui.reflow;

import java.util.ArrayList;

public class itemsList {

    private static ArrayList<Object> itemsList;

    public static ArrayList<Object> getItemsList() {
        if (itemsList == null) {
            synchronized (itemsList.class) {
                if (itemsList == null) {
                    itemsList = new ArrayList<Object>();
                }
            }
        }
        return itemsList;
    }
}
